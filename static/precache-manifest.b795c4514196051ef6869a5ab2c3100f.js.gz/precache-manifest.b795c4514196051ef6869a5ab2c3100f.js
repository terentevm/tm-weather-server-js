self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "99edac4f23caff6b4bc19368fed1d67d",
    "url": "/index.html"
  },
  {
    "revision": "bc3faef12ea902663377",
    "url": "/static/css/main.2b97d84b.chunk.css"
  },
  {
    "revision": "80bc66d0698afa9bbbde",
    "url": "/static/js/2.48f30b1d.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/static/js/2.48f30b1d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "bc3faef12ea902663377",
    "url": "/static/js/main.34d0968c.chunk.js"
  },
  {
    "revision": "abd052fcac3aa0b701a0",
    "url": "/static/js/runtime-main.6ef234fa.js"
  },
  {
    "revision": "eb2c4a38fefcdc498e5ad91e1a55611c",
    "url": "/static/media/bookmark.eb2c4a38.svg"
  },
  {
    "revision": "346b346f5561d4876d9dede130c3b66a",
    "url": "/static/media/clear.346b346f.svg"
  },
  {
    "revision": "47a425fb35edf3b279aa48854bb78b87",
    "url": "/static/media/clear_day.47a425fb.webp"
  },
  {
    "revision": "86356a025949388eaa992407b0bb54f3",
    "url": "/static/media/clear_night.86356a02.webp"
  },
  {
    "revision": "7ee70f9fbfac3ec8b5360a4b53007c00",
    "url": "/static/media/cloudy.7ee70f9f.svg"
  },
  {
    "revision": "3635970be649f524982a0e5d1d658232",
    "url": "/static/media/cloudy_day.3635970b.webp"
  },
  {
    "revision": "d1037515580eab0a637027cdfb7083bf",
    "url": "/static/media/cloudy_light_day.d1037515.webp"
  },
  {
    "revision": "2c356c8c8c7681a244add9c1a6b43a36",
    "url": "/static/media/cloudy_light_night.2c356c8c.webp"
  },
  {
    "revision": "96699d5c053a06be6e2b3ad2770bc72f",
    "url": "/static/media/cloudy_night.96699d5c.webp"
  },
  {
    "revision": "1d4cf2eb9001b6bf8dd999e04f541b3f",
    "url": "/static/media/cs.1d4cf2eb.svg"
  },
  {
    "revision": "d8277b2a94c5ddee377bf030ac800662",
    "url": "/static/media/de.d8277b2a.svg"
  },
  {
    "revision": "6c4a03a5de921b805dd8754acfb15e3e",
    "url": "/static/media/haze.6c4a03a5.svg"
  },
  {
    "revision": "55d1c59d334e5df52c917a9f532939e9",
    "url": "/static/media/humidity.55d1c59d.svg"
  },
  {
    "revision": "1724df32d94922ca2785f467a2f3f124",
    "url": "/static/media/light_rain_day.1724df32.webp"
  },
  {
    "revision": "daf7b8c2d501f2457b43ef3655563a89",
    "url": "/static/media/light_rain_night.daf7b8c2.webp"
  },
  {
    "revision": "5039864cceefa1c9cf8f8a3aebbbd405",
    "url": "/static/media/moon.5039864c.svg"
  },
  {
    "revision": "ef559ac7a308d7f1b5306734937dd031",
    "url": "/static/media/overcast-and-rain.ef559ac7.svg"
  },
  {
    "revision": "b3673467354aa397d42e76e43a8a56bf",
    "url": "/static/media/overcast-and-snow.b3673467.svg"
  },
  {
    "revision": "9d8867eeeff25cf57e5aa494ecf3a2b3",
    "url": "/static/media/overcast-and-wet-snow.9d8867ee.svg"
  },
  {
    "revision": "f50dfdb7787fe912542321d10ea5a44c",
    "url": "/static/media/overcast-thunderstorms-with-rain.f50dfdb7.svg"
  },
  {
    "revision": "bd652b9ee30ed7c7feb9c7cd66e73f2e",
    "url": "/static/media/overcast.bd652b9e.svg"
  },
  {
    "revision": "dd28626bd0ce1903f5dc595cb6fef690",
    "url": "/static/media/overcast.dd28626b.webp"
  },
  {
    "revision": "418c454c47665be2542b9c39ce420227",
    "url": "/static/media/partly-cloudy-and-light-rain.418c454c.svg"
  },
  {
    "revision": "29c5f202d036ec4aed3be6e79bc41ce7",
    "url": "/static/media/partly-cloudy-and-light-snow.29c5f202.svg"
  },
  {
    "revision": "075febfd9bf1429d48dd9464f094cb77",
    "url": "/static/media/partly-cloudy-and-rain.075febfd.svg"
  },
  {
    "revision": "e9ee5d2d8f0c7c29b2ff4b8ccca9a460",
    "url": "/static/media/partly-cloudy.e9ee5d2d.svg"
  },
  {
    "revision": "20964ed57b79a81ddd2a7dd7273d4e64",
    "url": "/static/media/pressure_light.20964ed5.svg"
  },
  {
    "revision": "4f033f466cffcd20197280b619f0e927",
    "url": "/static/media/rain_day.4f033f46.webp"
  },
  {
    "revision": "b8a91e4ef4b6f7042954f07e3ce060f0",
    "url": "/static/media/rain_night.b8a91e4e.webp"
  },
  {
    "revision": "ab3bfa2484862f0eb9d8efba7d9f7df7",
    "url": "/static/media/rain_snow.ab3bfa24.webp"
  },
  {
    "revision": "58ba14899e7b82e952a630fb6ddd3da3",
    "url": "/static/media/ru.58ba1489.svg"
  },
  {
    "revision": "84a2ffdcaeef2a39a5edba5e0df49f17",
    "url": "/static/media/snow_night.84a2ffdc.webp"
  },
  {
    "revision": "dd42591b7bfb55daa717a13e6d3a1240",
    "url": "/static/media/sun.dd42591b.svg"
  },
  {
    "revision": "b5dd790cb56a117c28342e6e2f53a14d",
    "url": "/static/media/sunrise.b5dd790c.svg"
  },
  {
    "revision": "b90192e5735cbadea3457c42976ab92d",
    "url": "/static/media/sunset.b90192e5.svg"
  },
  {
    "revision": "9dc542391f0aa20341074da3cbb235f1",
    "url": "/static/media/thunderstorm.9dc54239.webp"
  },
  {
    "revision": "d82015ef3ecd8c03606b97b4a618df8e",
    "url": "/static/media/tornado.d82015ef.svg"
  },
  {
    "revision": "8d36acbbbd4b5cf467ccacd5b4e705cf",
    "url": "/static/media/update.8d36acbb.svg"
  },
  {
    "revision": "51bb01ca07851685428c8b43e25bf6ef",
    "url": "/static/media/wind.51bb01ca.svg"
  }
]);